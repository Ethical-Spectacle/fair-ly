from .text_analyzer import TextAnalyzer # just let's ppl access it directly from the package
from .multimodal_analyzer import MultimodalAnalyzer