from .analyzer import FairlyAnalyzer # just let's ppl access it directly from the package
